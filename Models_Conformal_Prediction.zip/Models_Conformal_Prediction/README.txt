Installing:
conda install python=3 numpy pandas scikit-learn=0.20.4 cloudpickle
pip install nonconformist==1.2.5

Building models:
python conformal_prediction.py -i <training-file> -n 20 -m t -s t

Predicting:
python conformal_prediction.py -i <training-file> -n 20 -m p -s t -p <test-file>

Building and predicting:
python conformal_prediction.py -i <training-file> -n 20 -m b -s t -p <test-file>

Cross-validation (5-fold):
python conformal_prediction_cvX.py -i <training-file> -c 5 -s t



For the rdkit descriptor generation (rdkit_pc_smi.py):
use rdkit 2018.09.1.0
other versions will generate different values.
