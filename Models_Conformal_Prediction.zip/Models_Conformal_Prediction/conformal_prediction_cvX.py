#!/usr/bin/env python
 
def writeOutListsApp(filePath, dataLists, delimiter = '\t'):
    with open(filePath, 'a') as fd:
        numOfLists = len(dataLists)
        lenOfLists = len(dataLists[0])
        for lineNum in range(lenOfLists):
            tmpString = ""
            for column in range(numOfLists):
                tmpString += str(dataLists[column][lineNum]) + delimiter
            fd.write(tmpString.strip() + "\n")


import os,sys
from sklearn.ensemble import RandomForestClassifier
from nonconformist.icp import IcpClassifier
from nonconformist.nc import ProbEstClassifierNc, margin
import pandas as pd
import numpy as np
from argparse import ArgumentParser
from sklearn.utils import shuffle
from sklearn.model_selection import StratifiedKFold
from sklearn.model_selection import train_test_split
from sklearn.impute import SimpleImputer

parser = ArgumentParser()
parser.add_argument('-i','--infile', help='input training file')
parser.add_argument('-c','--cv', type=str, help='number of cv folds (default 5 folds)')
parser.add_argument('-s','--sep', type=str, choices=['t','c'], help='file separator: tab or comma')
args = parser.parse_args()

infile = args.infile
cv = args.cv
sep = args.sep

if infile == None or sep == None:
    parser.print_help(sys.stderr)
    sys.exit(1)

if cv == None:
    cv = 5
cv = int(cv)


if sep == 't':
    data = pd.read_csv(infile, sep='\t', header = 0, index_col = None)
if sep == 'c':
    data = pd.read_csv(infile, sep=',', header = 0, index_col = None)
#if 'name' or 'Name' or 'Molecule name' or '1' in data.columns:
if 'name' or 'Name' or 'Molecule name' in data.columns:
#    data.rename(columns={'name': 'id', 'Name': 'id', 'Molecule name': 'id', '1': 'id'}, inplace=True)
    data.rename(columns={'name': 'id', 'Name': 'id', 'Molecule name': 'id'}, inplace=True)

try:
    labels = data['id'].values
except:
    data.rename(columns={ data.columns[0]: "id" }, inplace = True)
    labels = data['id'].values
    print("/////////////////////// renaming column 1 to 'id' ///////////////////////")



if 'class' in data.columns:
    data.rename(columns={'class': 'target'}, inplace=True)

try:
    data.loc[data['target'] < 0, 'target'] = 0
except:
    data.rename(columns={ data.columns[1]: "target" }, inplace = True)
    data.loc[data['target'] < 0, 'target'] = 0
    print("/////////////////////// renaming column 2 to 'target' ///////////////////////")
    print (data)

target = data['target'].values
train = data.drop(['id'], axis=1, errors='ignore')
train = train.drop(['dataset'], axis=1, errors='ignore')
train = train.drop(['target'], axis=1, errors='ignore')
for col in train.columns:
    train[col] = pd.to_numeric(train[col], errors='coerce')
train.replace([np.inf, -np.inf], np.nan, inplace=True)
nancount = train.isnull().sum().sum()
train = train.drop(['target'], axis=1, errors='ignore').values
if nancount > 0:
    print ("imputing missing values:",nancount)
    imp = SimpleImputer(missing_values=np.nan, strategy='mean')
    impmodel = imp.fit(train)
    train = impmodel.transform(train)

X = train
y = target
del train, target

skf = StratifiedKFold(n_splits=cv)
skf.get_n_splits(X, y, labels)

xx = 0
outfile = infile + "_nonconf_pred_cv" + str(cv) + "_sum.csv"
f2 = open(outfile,'w')
f2.write('id\tp-value_low_class\tp-value_high_class\tclass\tmodel\n')
f2.close()

for train_index, test_index in skf.split(X, y, labels):
    X_train, X_test = X[train_index], X[test_index]
    y_train, y_test = y[train_index], y[test_index]
    labels_train, labels_test = labels[train_index], labels[test_index]

#    X_train2, X_cal, y_train2, y_cal = train_test_split(X_train, y_train, test_size=0.3, random_state=42)
    X_train2, X_cal, y_train2, y_cal = train_test_split(X_train, y_train, test_size=0.3)
    xx = xx + 1
    print (" Working on loop", xx)
 

    nc = ProbEstClassifierNc(RandomForestClassifier,margin,model_params={'n_estimators': 100})
    icp_norm = IcpClassifier(nc, condition=lambda instance: instance[1])

    icp_norm.fit(X_train2, y_train2)
    icp_norm.calibrate(X_cal, y_cal)

    ll = len(labels)
    num = [xx]*ll

    print ("\r Predicting from model", xx, end='')
    predicted = icp_norm.predict(X_test)
#    print (labels, y_test, predicted,num)
    predicted0 = [x[0] for x in predicted]
    predicted1 = [x[1] for x in predicted]
    writeOutListsApp(outfile, [labels_test, predicted0,  predicted1, y_test, num])

print (" - finished\n")
 
