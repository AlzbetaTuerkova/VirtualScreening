#!/bin/bash


ORIG=`basename ${1} .pdbqt`


for i in pose[0-9].pdb; do cp $i ${ORIG}_$i; done
