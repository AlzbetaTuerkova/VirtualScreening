#!/bin/bash

LIGAND=`basename ${1} .pdbqt`
PROTEIN=`basename ${2} .pdbqt`

vina --receptor ${PROTEIN}.pdbqt --ligand ${LIGAND}.pdbqt  --center_x 43.13 --center_y 44.03 --center_z 41.23 --size_x 15 --size_y 15  --size_z 15 --out ${LIGAND}_out.pdbqt --log ${LIGAND}.log --exhaustiveness 10 --cpu 10


