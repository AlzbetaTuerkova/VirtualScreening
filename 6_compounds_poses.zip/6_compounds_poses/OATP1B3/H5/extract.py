import sys


log = sys.argv[1]
output = open('affinity.dat', 'w')

for line in open(log, 'r'):
    if "0.000" in line:
        affinity = float(line.split()[1])
        inchikey = log.split('.')[0]
        output.write("%s\t" "%f\n" % (inchikey, affinity))

