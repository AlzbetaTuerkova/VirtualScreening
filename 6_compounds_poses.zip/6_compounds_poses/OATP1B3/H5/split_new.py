import sys, os

# Split ligand into separate poses

ligand = sys.argv[1]

with open(ligand, mode="r") as lig:
    reader = lig.read()
    for i, part in enumerate(reader.split("ENDMDL")):
        with open("pose" + str(i+1) + ".pdb", mode="w") as output_file:
            output_file.write(part)
